import { redirect } from "next/navigation";
import { getStaffSession } from "./staff-session";

/**
 * Server-side guard that enforces owner-only access.
 * Redirects to /admin if the user is not an active owner.
 *
 * @returns Staff session if authorized
 * @throws Redirects to /admin if unauthorized
 */
export async function requireOwner() {
  const session = await getStaffSession();

  if (!session) {
    redirect("/staff-login?redirect=/superadmin");
  }

  if (session.status !== "active" || session.role !== "owner") {
    redirect("/admin");
  }

  return session;
}
