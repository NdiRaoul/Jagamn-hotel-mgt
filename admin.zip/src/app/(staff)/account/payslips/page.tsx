import { getStaffSession } from "@/lib/auth/staff-session";
import { getStaffPayslips } from "@/lib/data/self-service";
import { redirect } from "next/navigation";
import PayslipsClient from "./payslips-client";

export const dynamic = "force-dynamic";

export default async function PayslipsPage() {
  const session = await getStaffSession();
  if (!session) redirect("/staff-login");

  const payslips = await getStaffPayslips(session.id);

  return <PayslipsClient payslips={payslips} staff={session} />;
}
