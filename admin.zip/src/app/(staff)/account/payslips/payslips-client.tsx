"use client";

import React, { useState } from "react";
import {
  FileText,
  Download,
  Calendar,
  Banknote,
  CheckCircle2,
  Clock,
  XCircle,
} from "lucide-react";
import { formatMoneyMinor } from "@/lib/currency";
import jsPDF from "jspdf";
import "jspdf-autotable";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Payslip } from "@/lib/data/self-service";

interface PayslipsClientProps {
  payslips: Payslip[];
  staff: {
    id: string;
    full_name: string;
    email: string;
    staff_code?: string;
  };
}

const statusConfig: Record<
  string,
  { label: string; icon: React.ReactNode; className: string }
> = {
  unpaid: {
    label: "Unpaid",
    icon: <Clock className="w-4 h-4" />,
    className: "bg-yellow-50 text-yellow-700 border-yellow-200",
  },
  processing: {
    label: "Processing",
    icon: <Clock className="w-4 h-4" />,
    className: "bg-blue-50 text-blue-700 border-blue-200",
  },
  paid: {
    label: "Paid",
    icon: <CheckCircle2 className="w-4 h-4" />,
    className: "bg-green-50 text-green-700 border-green-200",
  },
  failed: {
    label: "Failed",
    icon: <XCircle className="w-4 h-4" />,
    className: "bg-red-50 text-red-700 border-red-200",
  },
};

export default function PayslipsClient({
  payslips,
  staff,
}: PayslipsClientProps) {
  const [isGenerating, setIsGenerating] = useState<string | null>(null);

  const downloadPDF = async (payslip: Payslip) => {
    setIsGenerating(payslip.id);
    try {
      // Create PDF document
      const doc = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      });

      const pageWidth = doc.getPageWidth();
      const pageHeight = doc.getPageHeight();
      const margin = 20;
      const contentWidth = pageWidth - 2 * margin;

      let yPos = margin;

      // Header
      doc.setFontSize(20);
      doc.setTextColor(13, 33, 55); // #0D2137
      doc.text("JAGAMN PALACE", margin, yPos);

      yPos += 10;
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text("Payslip", margin, yPos);

      // Employee info
      yPos += 15;
      doc.setFontSize(11);
      doc.setTextColor(13, 33, 55);
      const infoY = yPos;
      doc.text(`Employee: ${staff.full_name}`, margin, infoY);
      doc.text(`Email: ${staff.email}`, margin, infoY + 7);
      doc.text(
        `Period: ${new Date(payslip.period_start).toLocaleDateString()} - ${new Date(payslip.period_end).toLocaleDateString()}`,
        margin,
        infoY + 14,
      );

      yPos = infoY + 30;

      // Earnings & Deductions Table
      const tableData = [
        ["Component", "Amount"],
        ["Gross Monthly Salary", formatMoneyMinor(payslip.gross_minor)],
        ["Deductions", formatMoneyMinor(payslip.deductions_minor)],
        ["Net Amount", formatMoneyMinor(payslip.net_minor)],
      ];

      doc.autoTable({
        startY: yPos,
        head: [tableData[0]],
        body: tableData.slice(1),
        margin: { left: margin, right: margin },
        columnStyles: {
          0: { cellWidth: contentWidth * 0.6 },
          1: { cellWidth: contentWidth * 0.4, halign: "right" },
        },
        styles: {
          font: "helvetica",
          fontSize: 10,
          cellPadding: 6,
          textColor: [50, 50, 50],
        },
        headStyles: {
          fillColor: [232, 146, 74], // #E8924A
          textColor: [255, 255, 255],
          fontStyle: "bold",
        },
      });

      // Footer with status
      yPos = (doc as any).lastAutoTable.finalY + 20;
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      const status =
        statusConfig[payslip.payment_status] || statusConfig.unpaid;
      doc.text(`Status: ${status.label}`, margin, yPos);

      if (payslip.paid_at) {
        doc.text(
          `Paid on: ${new Date(payslip.paid_at).toLocaleDateString()}`,
          margin,
          yPos + 7,
        );
      }

      // Generated info
      yPos = pageHeight - margin - 10;
      doc.setFontSize(8);
      doc.setTextColor(150, 150, 150);
      doc.text(`Generated: ${new Date().toLocaleString()}`, margin, yPos);

      // Download
      doc.save(`payslip_${staff.full_name}_${payslip.period_label}.pdf`);
    } finally {
      setIsGenerating(null);
    }
  };

  return (
    <div className="space-y-6">
      {payslips.length === 0 ? (
        <Card className="border border-gray-200">
          <CardContent className="pt-12 pb-12 text-center">
            <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No payslips available yet</p>
          </CardContent>
        </Card>
      ) : (
        <div className="overflow-hidden border border-gray-200 rounded-lg bg-white">
          <Table>
            <TableHeader className="bg-gray-50 border-b border-gray-200">
              <TableRow>
                <TableHead className="text-gray-700 font-semibold">
                  Period
                </TableHead>
                <TableHead className="text-gray-700 font-semibold text-right">
                  Gross
                </TableHead>
                <TableHead className="text-gray-700 font-semibold text-right">
                  Deductions
                </TableHead>
                <TableHead className="text-gray-700 font-semibold text-right">
                  Net
                </TableHead>
                <TableHead className="text-gray-700 font-semibold">
                  Status
                </TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payslips.map((payslip) => {
                const status =
                  statusConfig[payslip.payment_status] || statusConfig.unpaid;
                return (
                  <TableRow
                    key={payslip.id}
                    className="border-b border-gray-100 hover:bg-gray-50"
                  >
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <div>
                          <p className="font-medium text-gray-900">
                            {payslip.period_label}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(
                              payslip.period_start,
                            ).toLocaleDateString()}{" "}
                            -{" "}
                            {new Date(payslip.period_end).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {formatMoneyMinor(payslip.gross_minor)}
                    </TableCell>
                    <TableCell className="text-right text-gray-600">
                      {formatMoneyMinor(payslip.deductions_minor)}
                    </TableCell>
                    <TableCell className="text-right font-semibold text-gray-900">
                      {formatMoneyMinor(payslip.net_minor)}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={`flex items-center gap-1 w-fit ${status.className}`}
                      >
                        {status.icon}
                        {status.label}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => downloadPDF(payslip)}
                        disabled={isGenerating === payslip.id}
                        className="text-[#E8924A] hover:text-[#E8924A] hover:bg-[#E8924A]/10"
                      >
                        <Download className="w-4 h-4" />
                        <span className="ml-2">
                          {isGenerating === payslip.id
                            ? "Generating..."
                            : "Download"}
                        </span>
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
