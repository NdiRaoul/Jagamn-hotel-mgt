import { getStaffSession } from "@/lib/auth/staff-session";
import { getPayoutAccounts } from "@/lib/data/self-service";
import { redirect } from "next/navigation";
import PayoutClient from "./payout-client";

export const dynamic = "force-dynamic";

export default async function PayoutPage() {
  const session = await getStaffSession();

  if (!session || session.status !== "active") {
    redirect("/staff-login");
  }

  const accounts = await getPayoutAccounts(session.id);

  return <PayoutClient accounts={accounts} />;
}
