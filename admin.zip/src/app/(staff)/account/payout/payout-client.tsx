"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Wallet,
  Plus,
  CheckCircle2,
  Clock,
  Trash2,
  Star,
  ExternalLink,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import type { PayoutAccount } from "@/lib/data/self-service";

interface Props {
  accounts: PayoutAccount[];
}

const methodConfig: Record<
  string,
  { label: string; description: string; icon: React.ReactNode }
> = {
  stripe: {
    label: "Stripe Connect",
    description: "Transfer to your Stripe Connect account",
    icon: <Wallet className="w-5 h-5" />,
  },
  mtn_momo: {
    label: "MTN Mobile Money",
    description: "Transfer to your MTN MoMo number",
    icon: <Wallet className="w-5 h-5" />,
  },
  orange_money: {
    label: "Orange Money",
    description: "Transfer to your Orange Money number",
    icon: <Wallet className="w-5 h-5" />,
  },
  bank: {
    label: "Bank Transfer",
    description: "Direct transfer to your bank account",
    icon: <Wallet className="w-5 h-5" />,
  },
};

export default function PayoutClient({ accounts: initialAccounts }: Props) {
  const router = useRouter();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState("mtn_momo");
  const [accountHolder, setAccountHolder] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [provider, setProvider] = useState("");
  const [isSetupStripe, setIsSetupStripe] = useState(false);

  const handleAddAccount = async () => {
    if (!accountHolder || !accountNumber) {
      alert("Please fill in all required fields");
      return;
    }

    setIsAdding(true);
    try {
      const res = await fetch("/api/account/payout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          method: selectedMethod,
          provider: provider || undefined,
          account_number: accountNumber,
          account_holder_name: accountHolder,
        }),
      });

      if (!res.ok) throw new Error("Failed to add account");

      setIsAddOpen(false);
      setAccountHolder("");
      setAccountNumber("");
      setProvider("");
      setSelectedMethod("mtn_momo");
      router.refresh();
    } catch (error) {
      console.error("Error adding account:", error);
      alert("Failed to add account");
    } finally {
      setIsAdding(false);
    }
  };

  const handleSetDefault = async (accountId: string) => {
    try {
      const res = await fetch("/api/account/payout", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ account_id: accountId }),
      });

      if (!res.ok) throw new Error("Failed to update default");
      router.refresh();
    } catch (error) {
      console.error("Error updating default:", error);
      alert("Failed to update default account");
    }
  };

  const handleDeleteAccount = async (accountId: string) => {
    if (!confirm("Are you sure you want to delete this payout account?")) {
      return;
    }

    try {
      const res = await fetch(`/api/account/payout?id=${accountId}`, {
        method: "DELETE",
      });

      if (!res.ok) throw new Error("Failed to delete account");
      router.refresh();
    } catch (error) {
      console.error("Error deleting account:", error);
      alert("Failed to delete account");
    }
  };

  const handleSetupStripe = async () => {
    setIsSetupStripe(true);
    try {
      const res = await fetch("/api/account/payout/setup-intent", {
        method: "POST",
      });

      if (!res.ok) throw new Error("Failed to create Stripe setup");

      const data = await res.json();
      // Redirect to Stripe onboarding
      window.location.href = data.url;
    } catch (error) {
      console.error("Error setting up Stripe:", error);
      alert("Failed to set up Stripe account");
    } finally {
      setIsSetupStripe(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Stripe Alert */}
      {!initialAccounts.some((a) => a.method === "stripe") && (
        <Alert className="bg-blue-50 border-blue-200">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">
            <strong>Recommended:</strong> Set up your Stripe Connect account for
            faster, automated payouts. You can also add alternative payment methods
            below.
          </AlertDescription>
        </Alert>
      )}

      {/* Payout Accounts List */}
      {initialAccounts.length === 0 ? (
        <Card className="border border-gray-200">
          <CardContent className="pt-12 pb-12 text-center">
            <Wallet className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600 font-medium mb-4">
              No payout accounts configured
            </p>
            <p className="text-gray-500 text-sm mb-6">
              Add your first payout method to receive your salary
            </p>
            <div className="flex flex-col gap-3 max-w-xs mx-auto">
              <Button
                onClick={handleSetupStripe}
                disabled={isSetupStripe}
                className="w-full bg-[#E8924A] hover:bg-[#E8924A]/90"
              >
                {isSetupStripe ? "Setting up..." : "Set Up Stripe Connect"}
              </Button>
              <Button
                variant="outline"
                onClick={() => setIsAddOpen(true)}
                className="w-full"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Payment Method
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {initialAccounts.map((account) => {
            const config = methodConfig[account.method];
            const isStripe = account.method === "stripe";
            const statusBadge = account.is_verified ? (
              <Badge className="bg-green-100 text-green-800 text-[10px] font-black">
                VERIFIED
              </Badge>
            ) : (
              <Badge className="bg-yellow-100 text-yellow-800 text-[10px] font-black">
                PENDING
              </Badge>
            );

            return (
              <Card
                key={account.id}
                className={
                  account.is_default
                    ? "border-2 border-[#E8924A]"
                    : "border border-gray-200"
                }
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="text-gray-600">{config.icon}</div>
                      <div className="flex-1">
                        <CardTitle className="text-lg">{config.label}</CardTitle>
                        <p className="text-sm text-gray-500">
                          {config.description}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">{statusBadge}</div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Account details */}
                  <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                    {account.account_holder_name && (
                      <div>
                        <p className="text-xs text-gray-600 uppercase tracking-wide">
                          Account Holder
                        </p>
                        <p className="text-gray-900 font-medium">
                          {account.account_holder_name}
                        </p>
                      </div>
                    )}
                    {account.account_last4 && (
                      <div>
                        <p className="text-xs text-gray-600 uppercase tracking-wide">
                          Account
                        </p>
                        <p className="text-gray-900 font-mono">
                          ••••{account.account_last4}
                        </p>
                      </div>
                    )}
                    {account.provider && (
                      <div>
                        <p className="text-xs text-gray-600 uppercase tracking-wide">
                          Provider
                        </p>
                        <p className="text-gray-900 font-medium capitalize">
                          {account.provider}
                        </p>
                      </div>
                    )}
                    {isStripe && account.stripe_status && (
                      <div>
                        <p className="text-xs text-gray-600 uppercase tracking-wide">
                          Stripe Status
                        </p>
                        <p className="text-gray-900 font-medium capitalize">
                          {account.stripe_status}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Stripe verification notice */}
                  {isStripe && account.stripe_status === "pending" && (
                    <Alert className="bg-yellow-50 border-yellow-200">
                      <Clock className="h-4 w-4 text-yellow-600" />
                      <AlertDescription className="text-yellow-800 text-sm">
                        Stripe account setup in progress. Complete onboarding to
                        receive payouts.
                      </AlertDescription>
                    </Alert>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    {!account.is_default && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSetDefault(account.id)}
                        className="flex-1"
                      >
                        <Star className="w-4 h-4 mr-2" />
                        Set as Default
                      </Button>
                    )}
                    {account.is_default && (
                      <Button
                        variant="outline"
                        size="sm"
                        disabled
                        className="flex-1 bg-gray-50"
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2 text-green-600" />
                        Default
                      </Button>
                    )}
                    {isStripe && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          window.open(
                            `https://dashboard.stripe.com/account`,
                            "_blank",
                          );
                        }}
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteAccount(account.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {/* Add button */}
          <Button
            variant="outline"
            onClick={() => {
              setIsAddOpen(true);
              setSelectedMethod("mtn_momo");
            }}
            className="w-full"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Another Payment Method
          </Button>
        </div>
      )}

      {/* Add Account Dialog */}
      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Payout Account</DialogTitle>
            <DialogDescription>
              Add a new payment method for salary transfers
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="method" className="text-gray-700">
                Payment Method
              </Label>
              <Select value={selectedMethod} onValueChange={setSelectedMethod}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mtn_momo">MTN Mobile Money</SelectItem>
                  <SelectItem value="orange_money">Orange Money</SelectItem>
                  <SelectItem value="bank">Bank Transfer</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="accountHolder" className="text-gray-700">
                Account Holder Name
              </Label>
              <Input
                id="accountHolder"
                placeholder="e.g., Your Name"
                value={accountHolder}
                onChange={(e) => setAccountHolder(e.target.value)}
                className="mt-1"
              />
            </div>

            {selectedMethod === "bank" && (
              <div>
                <Label htmlFor="provider" className="text-gray-700">
                  Bank Name
                </Label>
                <Input
                  id="provider"
                  placeholder="e.g., Cameroon Commercial Bank"
                  value={provider}
                  onChange={(e) => setProvider(e.target.value)}
                  className="mt-1"
                />
              </div>
            )}

            <div>
              <Label htmlFor="accountNumber" className="text-gray-700">
                {selectedMethod === "bank"
                  ? "Account Number"
                  : "Phone Number"}
              </Label>
              <Input
                id="accountNumber"
                placeholder={
                  selectedMethod === "bank"
                    ? "Your bank account number"
                    : "e.g., +237 650 000 000"
                }
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                className="mt-1"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAddOpen(false)}
              disabled={isAdding}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddAccount}
              disabled={isAdding}
              className="bg-[#E8924A] hover:bg-[#E8924A]/90"
            >
              {isAdding ? "Adding..." : "Add Account"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
  const [accounts, setAccounts] = useState<PayoutAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState("mtn_momo");
  const [accountHolder, setAccountHolder] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [provider, setProvider] = useState("");
  const [isSetupStripe, setIsSetupStripe] = useState(false);

  // Fetch accounts
  useEffect(() => {
    const fetchAccounts = async () => {
      try {
        const res = await fetch("/api/account/payout");
        if (!res.ok) throw new Error("Failed to fetch accounts");
        const data = await res.json();
        setAccounts(data.accounts);
      } catch (error) {
        console.error("Error fetching accounts:", error);
        toast({
          title: "Error",
          description: "Failed to load payout accounts",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchAccounts();
  }, [toast]);

  const handleAddAccount = async () => {
    if (!accountHolder || !accountNumber) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    setIsAdding(true);
    try {
      const res = await fetch("/api/account/payout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          method: selectedMethod,
          provider: provider || undefined,
          account_number: accountNumber,
          account_holder_name: accountHolder,
          is_default: accounts.length === 0, // Auto-set as default if first account
        }),
      });

      if (!res.ok) throw new Error("Failed to add account");

      const data = await res.json();
      setAccounts((prev) =>
        accounts.length === 0
          ? [data.account]
          : [
              ...prev.map((a) => ({ ...a, is_default: false })),
              data.account,
            ],
      );

      toast({
        title: "Success",
        description: "Payout account added successfully",
      });

      setIsAddOpen(false);
      setAccountHolder("");
      setAccountNumber("");
      setProvider("");
      setSelectedMethod("mtn_momo");
    } catch (error) {
      console.error("Error adding account:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add account",
        variant: "destructive",
      });
    } finally {
      setIsAdding(false);
    }
  };

  const handleSetDefault = async (accountId: string) => {
    try {
      const res = await fetch("/api/account/payout", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ account_id: accountId, is_default: true }),
      });

      if (!res.ok) throw new Error("Failed to update default");

      setAccounts((prev) =>
        prev.map((a) => ({
          ...a,
          is_default: a.id === accountId,
        })),
      );

      toast({
        title: "Success",
        description: "Default payout account updated",
      });
    } catch (error) {
      console.error("Error updating default:", error);
      toast({
        title: "Error",
        description: "Failed to update default account",
        variant: "destructive",
      });
    }
  };

  const handleDeleteAccount = async (accountId: string) => {
    if (!confirm("Are you sure you want to delete this payout account?")) {
      return;
    }

    try {
      const res = await fetch(`/api/account/payout?account_id=${accountId}`, {
        method: "DELETE",
      });

      if (!res.ok) throw new Error("Failed to delete account");

      setAccounts((prev) => prev.filter((a) => a.id !== accountId));

      toast({
        title: "Success",
        description: "Payout account deleted",
      });
    } catch (error) {
      console.error("Error deleting account:", error);
      toast({
        title: "Error",
        description: "Failed to delete account",
        variant: "destructive",
      });
    }
  };

  const handleSetupStripe = async () => {
    setIsSetupStripe(true);
    try {
      const res = await fetch("/api/account/payout/setup-intent", {
        method: "POST",
      });

      if (!res.ok) throw new Error("Failed to create Stripe setup");

      const data = await res.json();

      // Redirect to Stripe onboarding
      window.location.href = data.url;
    } catch (error) {
      console.error("Error setting up Stripe:", error);
      toast({
        title: "Error",
        description: "Failed to set up Stripe account",
        variant: "destructive",
      });
    } finally {
      setIsSetupStripe(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Stripe Alert */}
      {!accounts.some((a) => a.method === "stripe") && (
        <Alert className="bg-blue-50 border-blue-200 text-blue-900">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">
            <strong>Recommended:</strong> Set up your Stripe Connect account for faster,
            automated payouts. You can also add alternative payment methods below.
          </AlertDescription>
        </Alert>
      )}

      {/* Payout Accounts List */}
      {loading ? (
        <div className="text-center py-8">
          <Loader className="w-6 h-6 animate-spin mx-auto text-gray-400 mb-2" />
          <p className="text-gray-500">Loading payout accounts...</p>
        </div>
      ) : accounts.length === 0 ? (
        <Card className="border border-gray-200">
          <CardContent className="pt-12 pb-12 text-center">
            <Wallet className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600 font-medium mb-4">No payout accounts configured</p>
            <p className="text-gray-500 text-sm mb-6">
              Add your first payout method to receive your salary
            </p>
            <div className="flex flex-col gap-3 max-w-xs mx-auto">
              <Button
                onClick={handleSetupStripe}
                disabled={isSetupStripe}
                className="w-full bg-[#E8924A] hover:bg-[#E8924A]/90"
              >
                {isSetupStripe ? "Setting up..." : "Set Up Stripe Connect"}
              </Button>
              <Button
                variant="outline"
                onClick={() => setIsAddOpen(true)}
                className="w-full"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Payment Method
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {accounts.map((account) => {
            const config = methodConfig[account.method];
            const isStripe = account.method === "stripe";
            const statusBadge =
              isStripe && account.stripe_status === "verified" ? (
                <Badge className="bg-green-100 text-green-800">Verified</Badge>
              ) : account.is_verified ? (
                <Badge className="bg-green-100 text-green-800">Active</Badge>
              ) : (
                <Badge variant="outline" className="text-yellow-700">
                  Pending
                </Badge>
              );

            return (
              <Card key={account.id} className={account.is_default ? "border-2 border-[#E8924A]" : "border border-gray-200"}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="text-gray-600">{config.icon}</div>
                      <div className="flex-1">
                        <CardTitle className="text-lg">{config.label}</CardTitle>
                        <p className="text-sm text-gray-500">{config.description}</p>
                      </div>
                    </div>
                    <div className="text-right">{statusBadge}</div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Account details */}
                  <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                    {account.account_holder_name && (
                      <div>
                        <p className="text-xs text-gray-600 uppercase tracking-wide">
                          Account Holder
                        </p>
                        <p className="text-gray-900 font-medium">
                          {account.account_holder_name}
                        </p>
                      </div>
                    )}
                    {account.account_last4 && (
                      <div>
                        <p className="text-xs text-gray-600 uppercase tracking-wide">
                          Account
                        </p>
                        <p className="text-gray-900 font-mono">
                          ••••{account.account_last4}
                        </p>
                      </div>
                    )}
                    {account.provider && (
                      <div>
                        <p className="text-xs text-gray-600 uppercase tracking-wide">
                          Provider
                        </p>
                        <p className="text-gray-900 font-medium capitalize">
                          {account.provider}
                        </p>
                      </div>
                    )}
                    {isStripe && account.stripe_status && (
                      <div>
                        <p className="text-xs text-gray-600 uppercase tracking-wide">
                          Stripe Status
                        </p>
                        <p className="text-gray-900 font-medium capitalize">
                          {account.stripe_status}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Stripe verification notice */}
                  {isStripe && account.stripe_status === "pending" && (
                    <Alert className="bg-yellow-50 border-yellow-200">
                      <Clock className="h-4 w-4 text-yellow-600" />
                      <AlertDescription className="text-yellow-800 text-sm">
                        Stripe account setup in progress. Complete onboarding to receive payouts.
                      </AlertDescription>
                    </Alert>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    {!account.is_default && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSetDefault(account.id)}
                        className="flex-1"
                      >
                        <Star className="w-4 h-4 mr-2" />
                        Set as Default
                      </Button>
                    )}
                    {account.is_default && (
                      <Button
                        variant="outline"
                        size="sm"
                        disabled
                        className="flex-1 bg-gray-50"
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2 text-green-600" />
                        Default
                      </Button>
                    )}
                    {isStripe && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          window.open(
                            `https://dashboard.stripe.com/account`,
                            "_blank",
                          );
                        }}
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteAccount(account.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {/* Add button */}
          <Button
            variant="outline"
            onClick={() => {
              setIsAddOpen(true);
              setSelectedMethod("mtn_momo");
            }}
            className="w-full"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Another Payment Method
          </Button>
        </div>
      )}

      {/* Add Account Dialog */}
      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Payout Account</DialogTitle>
            <DialogDescription>
              Add a new payment method for salary transfers
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="method" className="text-gray-700">
                Payment Method
              </Label>
              <Select value={selectedMethod} onValueChange={setSelectedMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mtn_momo">MTN Mobile Money</SelectItem>
                  <SelectItem value="orange_money">Orange Money</SelectItem>
                  <SelectItem value="bank">Bank Transfer</SelectItem>
                  <SelectItem value="manual">Manual Payment</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="accountHolder" className="text-gray-700">
                Account Holder Name
              </Label>
              <Input
                id="accountHolder"
                placeholder="e.g., Your Name"
                value={accountHolder}
                onChange={(e) => setAccountHolder(e.target.value)}
              />
            </div>

            {selectedMethod !== "manual" && (
              <>
                {selectedMethod === "bank" && (
                  <div>
                    <Label htmlFor="provider" className="text-gray-700">
                      Bank Name
                    </Label>
                    <Input
                      id="provider"
                      placeholder="e.g., Cameroon Commercial Bank"
                      value={provider}
                      onChange={(e) => setProvider(e.target.value)}
                    />
                  </div>
                )}

                <div>
                  <Label htmlFor="accountNumber" className="text-gray-700">
                    {selectedMethod === "bank"
                      ? "Account Number"
                      : selectedMethod === "mtn_momo"
                        ? "Phone Number"
                        : "Phone Number"}
                  </Label>
                  <Input
                    id="accountNumber"
                    placeholder={
                      selectedMethod === "bank"
                        ? "Your bank account number"
                        : selectedMethod === "mtn_momo"
                          ? "e.g., +237 650 000 000"
                          : "e.g., +237 650 000 000"
                    }
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                  />
                </div>
              </>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAddOpen(false)}
              disabled={isAdding}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddAccount}
              disabled={isAdding}
              className="bg-[#E8924A] hover:bg-[#E8924A]/90"
            >
              {isAdding ? "Adding..." : "Add Account"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
