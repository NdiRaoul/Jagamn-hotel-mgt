"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, Save } from "lucide-react";
import type { StaffProfile } from "@/lib/data/self-service";
import { formatMoney } from "@/lib/currency";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface Props {
  profile: StaffProfile;
}

export default function ProfileClient({ profile }: Props) {
  const router = useRouter();
  const [phone, setPhone] = useState(profile.phone || "");
  const [isSaving, setIsSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const res = await fetch("/api/account/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone }),
      });

      if (res.ok) {
        router.refresh();
      } else {
        const data = await res.json();
        alert(`Error: ${data.error}`);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // TODO: Implement avatar upload to Supabase Storage
    // For now, just show a placeholder message
    alert("Avatar upload will be implemented with Supabase Storage bucket");
  };

  return (
    <div className="space-y-6">
      {/* Profile Card */}
      <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Avatar */}
          <div className="flex flex-col items-center gap-4">
            <Avatar className="w-32 h-32 border-4 border-gray-100">
              {profile.avatar_url && <AvatarImage src={profile.avatar_url} />}
              <AvatarFallback className="text-3xl manrope-bold bg-[#0D2137] text-white">
                {profile.full_name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <label className="cursor-pointer">
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleAvatarUpload}
                disabled={isUploading}
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={isUploading}
                asChild
              >
                <span>
                  <Upload className="w-4 h-4 mr-2" />
                  {isUploading ? "Uploading..." : "Change Photo"}
                </span>
              </Button>
            </label>
          </div>

          {/* Details */}
          <div className="flex-1 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  Full Name
                </Label>
                <p className="manrope-bold text-lg text-[#0D2137] mt-1">
                  {profile.full_name}
                </p>
              </div>
              <div>
                <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  Email
                </Label>
                <p className="manrope-bold text-lg text-[#0D2137] mt-1">
                  {profile.email}
                </p>
              </div>
              <div>
                <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  Role
                </Label>
                <p className="manrope-bold text-lg text-[#0D2137] mt-1 capitalize">
                  {profile.role}
                </p>
              </div>
              <div>
                <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  Department
                </Label>
                <p className="manrope-bold text-lg text-[#0D2137] mt-1">
                  {profile.department || "—"}
                </p>
              </div>
              <div>
                <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  Staff Code
                </Label>
                <p className="manrope-bold text-lg text-[#0D2137] mt-1">
                  {profile.staff_code || "—"}
                </p>
              </div>
              <div>
                <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  Hire Date
                </Label>
                <p className="manrope-bold text-lg text-[#0D2137] mt-1">
                  {profile.hire_date
                    ? new Date(profile.hire_date).toLocaleDateString()
                    : "—"}
                </p>
              </div>
            </div>

            <div className="pt-6 border-t border-gray-100">
              <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                Annual Salary
              </Label>
              <p className="manrope-bold text-2xl text-[#0D2137] mt-1">
                {formatMoney(profile.salary)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Editable Fields */}
      <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm">
        <h2 className="manrope-bold text-xl text-[#0D2137] mb-6">
          Contact Information
        </h2>
        <div className="space-y-4">
          <div>
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+237 6XX XXX XXX"
              className="mt-1"
            />
          </div>
          <Button onClick={handleSave} disabled={isSaving}>
            <Save className="w-4 h-4 mr-2" />
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </div>
    </div>
  );
}
