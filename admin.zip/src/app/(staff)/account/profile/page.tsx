import { getStaffSession } from "@/lib/auth/staff-session";
import { getStaffProfile } from "@/lib/data/self-service";
import { redirect } from "next/navigation";
import ProfileClient from "./profile-client";

export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const session = await getStaffSession();

  if (!session || session.status !== "active") {
    redirect("/staff-login");
  }

  const profile = await getStaffProfile(session.id);

  if (!profile) {
    return (
      <div className="bg-white rounded-2xl p-8 text-center">
        <p className="text-red-500">Profile not found</p>
      </div>
    );
  }

  return <ProfileClient profile={profile} />;
}
