import { getStaffSession } from "@/lib/auth/staff-session";
import Link from "next/link";
import { User, Calendar, FileText, Wallet } from "lucide-react";
import { redirect } from "next/navigation";

export default async function AccountLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getStaffSession();

  if (!session || session.status !== "active") {
    redirect("/staff-login");
  }

  const navItems = [
    { href: "/account/profile", label: "Profile", icon: User },
    { href: "/account/leave", label: "Leave", icon: Calendar },
    { href: "/account/payslips", label: "Payslips", icon: FileText },
    { href: "/account/payout", label: "Payout", icon: Wallet },
  ];

  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="manrope-bold text-3xl md:text-4xl text-[#0D2137] mb-2">
            My Account
          </h1>
          <p className="text-sm text-slate-500">
            Manage your profile, leave requests, payslips, and payout accounts
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-white border border-gray-100 hover:border-[#0D2137] hover:bg-[#0D2137] hover:text-white transition-all text-sm font-bold whitespace-nowrap"
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          ))}
        </div>

        {/* Content */}
        {children}
      </div>
    </div>
  );
}
