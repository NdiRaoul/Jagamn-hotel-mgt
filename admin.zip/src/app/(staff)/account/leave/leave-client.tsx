"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar, Plus, X } from "lucide-react";
import type { LeaveRequest, LeaveBalance } from "@/lib/data/self-service";

interface Props {
  requests: LeaveRequest[];
  balances: LeaveBalance[];
  leaveTypes: any[];
}

export default function LeaveClient({ requests, balances, leaveTypes }: Props) {
  const router = useRouter();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [leaveTypeId, setLeaveTypeId] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [reason, setReason] = useState("");

  const handleSubmit = async () => {
    if (!leaveTypeId || !startDate || !endDate) {
      alert("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch("/api/account/leave", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leave_type_id: leaveTypeId,
          start_date: startDate,
          end_date: endDate,
          reason,
        }),
      });

      if (res.ok) {
        setIsDialogOpen(false);
        setLeaveTypeId("");
        setStartDate("");
        setEndDate("");
        setReason("");
        router.refresh();
      } else {
        const data = await res.json();
        alert(`Error: ${data.error}`);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = async (requestId: string) => {
    if (!confirm("Are you sure you want to cancel this leave request?")) {
      return;
    }

    const res = await fetch(`/api/account/leave?id=${requestId}`, {
      method: "DELETE",
    });

    if (res.ok) {
      router.refresh();
    } else {
      const data = await res.json();
      alert(`Error: ${data.error}`);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { label: string; className: string }> = {
      pending: { label: "Pending", className: "bg-yellow-100 text-yellow-700" },
      approved: { label: "Approved", className: "bg-green-100 text-green-700" },
      rejected: { label: "Rejected", className: "bg-red-100 text-red-700" },
    };
    const variant = variants[status] || variants.pending;
    return (
      <Badge
        className={`text-[10px] font-black uppercase ${variant.className}`}
      >
        {variant.label}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      {/* Leave Balances */}
      <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm">
        <h2 className="manrope-bold text-xl text-[#0D2137] mb-6">
          Leave Balances ({new Date().getFullYear()})
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {balances.map((balance) => (
            <div
              key={balance.leave_type_id}
              className="p-4 rounded-xl border border-gray-100 bg-gray-50"
            >
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">
                {balance.leave_type_name}
              </p>
              <div className="flex items-baseline gap-2">
                <span className="manrope-bold text-3xl text-[#0D2137]">
                  {balance.remaining}
                </span>
                <span className="text-sm text-slate-500">
                  / {balance.accrued} days
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {balance.used} days used
              </p>
            </div>
          ))}
          {balances.length === 0 && (
            <p className="text-slate-400 italic col-span-3">
              No leave balances configured
            </p>
          )}
        </div>
      </div>

      {/* Leave Requests */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-6 md:p-8 border-b border-gray-50 flex items-center justify-between">
          <h2 className="manrope-bold text-xl text-[#0D2137]">
            My Leave Requests
          </h2>
          <Button onClick={() => setIsDialogOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            New Request
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50/50 border-b border-gray-50">
                <th className="px-6 md:px-8 py-5 text-[10px] font-black text-[#43474D] uppercase tracking-widest">
                  Type
                </th>
                <th className="px-6 md:px-8 py-5 text-[10px] font-black text-[#43474D] uppercase tracking-widest">
                  Dates
                </th>
                <th className="px-6 md:px-8 py-5 text-[10px] font-black text-[#43474D] uppercase tracking-widest text-center">
                  Days
                </th>
                <th className="px-6 md:px-8 py-5 text-[10px] font-black text-[#43474D] uppercase tracking-widest">
                  Reason
                </th>
                <th className="px-6 md:px-8 py-5 text-[10px] font-black text-[#43474D] uppercase tracking-widest text-center">
                  Status
                </th>
                <th className="px-6 md:px-8 py-5 text-[10px] font-black text-[#43474D] uppercase tracking-widest text-center">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {requests.map((request) => (
                <tr
                  key={request.id}
                  className="group hover:bg-gray-50/50 transition-colors"
                >
                  <td className="px-6 md:px-8 py-5">
                    <span className="manrope-bold text-sm text-[#0D2137]">
                      {request.leave_type?.name || "Unknown"}
                    </span>
                  </td>
                  <td className="px-6 md:px-8 py-5">
                    <div className="text-sm text-slate-600">
                      {new Date(request.start_date).toLocaleDateString()} →{" "}
                      {new Date(request.end_date).toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-6 md:px-8 py-5 text-center">
                    <span className="manrope-bold text-sm text-[#0D2137]">
                      {request.days}
                    </span>
                  </td>
                  <td className="px-6 md:px-8 py-5">
                    <span className="text-sm text-slate-600 line-clamp-2">
                      {request.reason || "—"}
                    </span>
                  </td>
                  <td className="px-6 md:px-8 py-5 text-center">
                    {getStatusBadge(request.status)}
                  </td>
                  <td className="px-6 md:px-8 py-5 text-center">
                    {request.status === "pending" && (
                      <Button
                        onClick={() => handleCancel(request.id)}
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
              {requests.length === 0 && (
                <tr>
                  <td
                    colSpan={6}
                    className="px-8 py-20 text-center text-slate-400 manrope-bold italic"
                  >
                    No leave requests yet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Request Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>New Leave Request</DialogTitle>
            <DialogDescription>
              Submit a new leave request for approval
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Leave Type *</Label>
              <Select value={leaveTypeId} onValueChange={setLeaveTypeId}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select leave type" />
                </SelectTrigger>
                <SelectContent>
                  {leaveTypes.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Start Date *</Label>
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label>End Date *</Label>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>
            <div>
              <Label>Reason</Label>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Optional reason for leave"
                className="mt-1"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setIsDialogOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              <Calendar className="w-4 h-4 mr-2" />
              {isSubmitting ? "Submitting..." : "Submit Request"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
