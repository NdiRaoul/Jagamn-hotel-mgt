import { getStaffSession } from "@/lib/auth/staff-session";
import { getLeaveRequests, getLeaveBalances } from "@/lib/data/self-service";
import { supabaseAdmin } from "@/lib/supabase-server";
import { redirect } from "next/navigation";
import LeaveClient from "./leave-client";

export const dynamic = "force-dynamic";

export default async function LeavePage() {
  const session = await getStaffSession();

  if (!session || session.status !== "active") {
    redirect("/staff-login");
  }

  const [requests, balances, leaveTypesData] = await Promise.all([
    getLeaveRequests(session.id),
    getLeaveBalances(session.id),
    supabaseAdmin
      .from("leave_types")
      .select("*")
      .eq("is_active", true)
      .order("name"),
  ]);

  const leaveTypes = leaveTypesData.data || [];

  return (
    <LeaveClient
      requests={requests}
      balances={balances}
      leaveTypes={leaveTypes}
    />
  );
}
